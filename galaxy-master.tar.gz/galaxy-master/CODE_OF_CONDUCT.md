# Galaxy Project Code of Conduct

This project is committed to providing a welcoming and harassment-free
experience for everyone. We therefore expect participants to abide by our Code
of Conduct, which can be found at:

https://galaxyproject.org/community/coc/
