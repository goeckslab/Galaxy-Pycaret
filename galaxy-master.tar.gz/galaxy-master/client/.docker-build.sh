#!/bin/bash
cd /data/client && \
    npm install && \
    grunt
