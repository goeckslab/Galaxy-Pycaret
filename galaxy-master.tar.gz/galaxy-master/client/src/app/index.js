/* eslint-disable simple-import-sort/exports */
// order is important here for unit tests, which is unfortunate and should be
// fixed in the future
export { getGalaxyInstance, setGalaxyInstance } from "./singleton";
export { default as galaxyFacade } from "./monitor";
