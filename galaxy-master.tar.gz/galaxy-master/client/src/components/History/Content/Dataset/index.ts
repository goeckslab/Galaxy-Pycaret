export type ItemUrls = {
    display?: string;
    edit: string;
    rerun?: string;
    visualize?: string;
    reportError?: string;
    showDetails: string | null;
};
